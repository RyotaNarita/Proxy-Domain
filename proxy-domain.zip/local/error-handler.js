var sm = require('service-metadata');
var hm = require('header-metadata');
var log = session.name('log') || session.createContext('log');



// エラー応答メッセージ
var obj = {
  "title": "",
  "status": null,
  "detail": "",
  "instance": "",
  "dateTime": "",
  "origin": "API Platform PrgOrg00 Proxy"
}
// エラーログ・メッセージ
var msg = '';

// リクエストURIを取得し、エンコード
var uri = sm.getVar('var://service/URI') || '';
var encoded_uri = encodeURIComponent(uri);
if (encoded_uri.indexOf('%3F') != -1) {
  encoded_uri = encoded_uri.split('%3F')[0];
}

// エラー・コード、エラー・メッセージを取得
var error_subcode = sm.getVar('var://service/error-subcode') || '';
var error_message = sm.getVar('var://service/error-message') || '';

/* 全エラー共通
obj.instance = encoded_uri;
if (requestDate.indexOf('.') != -1) {
  obj.dateTime = requestDate.split('.')[0] + '+09:00';
}
*/

// 流量超過エラー
if (error_subcode == '0x01d30004') {
  log.setVar('httpStatusCode', '429');
  sm.errorProtocolResponse = '429';
  sm.errorProtocolReasonPhrase = 'Too Many Requests';
  obj.title = "429 Too Many Requests";
  obj.status = 429;
  obj.detail = "Temporarily our service limited the requests rates, please try again after a few minutes.";
  msg = "流量閾値を超過しました。";
} else
// クライアントIP検査エラー
if (error_subcode == '0x01d30002') {
  log.setVar('httpStatusCode', '403');
  sm.errorProtocolResponse = '403';
  sm.errorProtocolReasonPhrase = 'Forbidden';
  obj.title = "403 Forbidden";
  obj.status = 403;
  obj.detail = "Your client IP doesn't match our authorized client IPs.";
  msg = "不正なクライアントIPからのアクセスが検出されました。";
} else
// URLマッチングエラー
if (error_message == 'No Resource') {
  log.setVar('httpStatusCode', '404');
  sm.errorProtocolResponse = '404';
  sm.errorProtocolReasonPhrase = 'Not Found';
  obj.title = "404 Not Found";
  obj.status = 404;
  obj.detail = "The requested URL was not found on this server.";
  msg = "不正なURLへのアクセスが検出されました。";
} else
// その他エラー
{
  log.setVar('httpStatusCode', '500');
  sm.errorProtocolResponse = '500';
  sm.errorProtocolReasonPhrase = 'Internal Server Error';
  obj.title = "500 Internal Server Error";
  obj.status = 500;
  obj.detail = "Internal Server Error has occurred.";
  msg = "予期せぬエラーが発生しました。";
}

// Content-Typeをセット
hm.response.set('Content-Type', 'application/problem+json');
// Content-Languageをセット
hm.response.set('Content-Language', 'en');
// エラー応答メッセージを出力
session.output.write(JSON.stringify(obj));
// エラーログを出力
try {
  console.options({'category':'proxy-error'}).info(msg);
} catch (e) {
  console.options({'category':'http'}).info(msg);
  console.options({'category':'mpgw'}).error('Proxy GatewayScript Error at local:///modules/error-handler.js: see the exception detail below...: %1$s', e);
}
