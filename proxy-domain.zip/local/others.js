// エラー・ルールへ遷移
session.reject('No Resource'); 
